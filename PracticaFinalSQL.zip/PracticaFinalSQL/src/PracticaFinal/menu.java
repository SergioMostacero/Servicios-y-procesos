package PracticaFinal;

import java.sql.*;
import java.util.Scanner;

public class menu {
    static Scanner teclado = new Scanner(System.in);

    public static void mostrarMenu() {
        System.out.println("Seleccione una opción:");
        System.out.println("1. Administrador");
        System.out.println("2. Empleado");
        System.out.println("3. Cliente");
        System.out.print("Opción: ");
    }

    public static void iniciarSesion() {
        System.out.print("Introduce tu alias: ");
        String alias = teclado.nextLine();
        System.out.print("Introduce tu clave: ");
        String clave = teclado.nextLine();

        String consulta = "SELECT rol FROM Usuario WHERE Alias = ? AND Clave = ?";
        try (Connection conexion = ConexionBase.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(consulta)) {

            sentencia.setString(1, alias);
            sentencia.setString(2, clave);
            ResultSet rs = sentencia.executeQuery();

            if (rs.next()) {
                String rol = rs.getString("rol");
                System.out.println("Has iniciado sesión como " + rol);
                mostrarOpciones(rol);
            } else {
                System.out.println("Alias o clave incorrectos.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void mostrarOpciones(String rol) {
        switch (rol) {
            case "Admin":
                mostrarMenuAdministrador();
                break;
            case "Empleado":
                mostrarMenuEmpleado();
                break;
            case "Cliente":
                mostrarMenuCliente();
                break;
            default:
                System.out.println("Rol desconocido.");
                break;
        }
    }

    public static void mostrarMenuAdministrador() {
        System.out.println("\nOpciones del Administrador:");
        System.out.println("1. Insertar/modificar/eliminar clientes");
        System.out.println("2. Insertar/modificar/eliminar empleados");
        System.out.println("3. Insertar/modificar/eliminar productos");
        System.out.print("Seleccione una opción: ");
        int opcion = teclado.nextInt();
        teclado.nextLine();  // Consumir el salto de línea

        switch (opcion) {
            case 1:
                gestionarClientes();
                break;
            case 2:
                gestionarEmpleados();
                break;
            case 3:
                gestionarProductos();
                break;
            default:
                System.out.println("Opción no válida.");
                break;
        }
    }

    public static void mostrarMenuEmpleado() {
        System.out.println("\nOpciones del Empleado:");
        System.out.println("1. Visualizar productos");
        System.out.println("2. Realizar ventas");
        System.out.println("3. Ver tickets generados");
        System.out.print("Seleccione una opción: ");
        int opcion = teclado.nextInt();
        teclado.nextLine();  // Consumir el salto de línea

        switch (opcion) {
            case 1:
                visualizarProductos();
                break;
            case 2:
                realizarVenta();
                break;
            case 3:
                verTicketsGenerados();
                break;
            default:
                System.out.println("Opción no válida.");
                break;
        }
    }

    public static void mostrarMenuCliente() {
        System.out.println("\nOpciones del Cliente:");
        System.out.println("1. Visualizar productos");
        System.out.println("2. Realizar compras");
        System.out.println("3. Ver historial de compras");
        System.out.println("4. Canjear puntos");
        System.out.print("Seleccione una opción: ");
        int opcion = teclado.nextInt();
        teclado.nextLine();  // Consumir el salto de línea

        switch (opcion) {
            case 1:
                visualizarProductos();
                break;
            case 2:
                realizarCompra();
                break;
            case 3:
                verHistorialCompras();
                break;
            case 4:
                canjearPuntos();
                break;
            default:
                System.out.println("Opción no válida.");
                break;
        }
    }

   //CLIENTES

    public static void gestionarClientes() {
        System.out.println("\nGestión de Clientes:");
        System.out.println("1. Insertar cliente");
        System.out.println("2. Modificar cliente");
        System.out.println("3. Eliminar cliente");
        System.out.print("Seleccione una opción: ");
        int opcion = teclado.nextInt();
        teclado.nextLine();  // Consumir el salto de línea

        switch (opcion) {
            case 1:
                insertarCliente();
                break;
            case 2:
                modificarCliente();
                break;
            case 3:
                eliminarCliente();
                break;
            default:
                System.out.println("Opción no válida.");
                break;
        }
    }

    private static void insertarCliente() {

        System.out.print("Introduce el nombre del cliente: ");
        String nombre = teclado.nextLine();
        System.out.print("Introduce la dirección del cliente: ");
        String direccion = teclado.nextLine();
        System.out.print("Introduce el alias del usuario: ");
        String alias = teclado.nextLine();

        String consulta = "INSERT INTO Cliente (Nombre, Direccion, Usuario_Alias) VALUES (?, ?, ?)";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement sentencia = conexion.prepareStatement(consulta)) {

            sentencia.setString(1, nombre);
            sentencia.setString(2, direccion);
            sentencia.setString(3, alias);
            int filas = sentencia.executeUpdate();

            if (filas > 0) {
                System.out.println("Cliente insertado correctamente.");
            } else {
                System.out.println("Error al insertar el cliente.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void modificarCliente() {
        System.out.print("Introduce el código del cliente a modificar: ");
        int codigoCliente = teclado.nextInt();
        teclado.nextLine();  // Consumir el salto de línea

        System.out.print("Introduce el nuevo nombre del cliente: ");
        String nombre = teclado.nextLine();
        System.out.print("Introduce la nueva dirección del cliente: ");
        String direccion = teclado.nextLine();

        String consulta = "UPDATE Cliente SET Nombre = ?, Direccion = ? WHERE numeroCliente = ?";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement sentencia = conexion.prepareStatement(consulta)) {

            sentencia.setString(1, nombre);
            sentencia.setString(2, direccion);
            sentencia.setInt(3, codigoCliente);
            int filas = sentencia.executeUpdate();

            if (filas > 0) {
                System.out.println("Cliente modificado correctamente.");
            } else {
                System.out.println("Error al modificar el cliente.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void eliminarCliente() {
        System.out.print("Introduce el código del cliente a eliminar: ");
        int codigoCliente = teclado.nextInt();

        String consulta = "DELETE FROM Cliente WHERE numeroCliente = ?";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement sentencia = conexion.prepareStatement(consulta)) {

            sentencia.setInt(1, codigoCliente);
            int filas = sentencia.executeUpdate();

            if (filas > 0) {
                System.out.println("Cliente eliminado correctamente.");
            } else {
                System.out.println("Error al eliminar el cliente.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    
    
    
    
    
    
    //EMPLEADOS

    public static void gestionarEmpleados() {
        System.out.println("\nGestión de Empleados:");
        System.out.println("1. Insertar empleado");
        System.out.println("2. Modificar empleado");
        System.out.println("3. Eliminar empleado");
        System.out.print("Seleccione una opción: ");
        int opcion = teclado.nextInt();
        teclado.nextLine();  // Consumir el salto de línea

        switch (opcion) {
            case 1:
                insertarEmpleado();
                break;
            case 2:
                modificarEmpleado();
                break;
            case 3:
                eliminarEmpleado();
                break;
            default:
                System.out.println("Opción no válida.");
                break;
        }
    }

    private static void insertarEmpleado() {
        System.out.print("Introduce el nombre del empleado: ");
        String nombre = teclado.nextLine();
        System.out.print("Introduce la fecha de alta (YYYY-MM-DD): ");
        String fechaAlta = teclado.nextLine();
        System.out.print("Introduce el alias del usuario: ");
        String alias = teclado.nextLine();

        String consulta = "INSERT INTO Empleado (Nombre, fechaAlta, Usuario_Alias) VALUES (?, ?, ?)";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement sentencia = conexion.prepareStatement(consulta)) {

            sentencia.setString(1, nombre);
            sentencia.setString(2, fechaAlta);
            sentencia.setString(3, alias);
            int filas = sentencia.executeUpdate();

            if (filas > 0) {
                System.out.println("Empleado insertado correctamente.");
            } else {
                System.out.println("Error al insertar el empleado.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void modificarEmpleado() {

        System.out.print("Introduce el código del empleado a modificar: ");
        int codigoEmpleado = teclado.nextInt();
        teclado.nextLine();  // Consumir el salto de línea

        System.out.print("Introduce el nuevo nombre del empleado: ");
        String nombre = teclado.nextLine();
        System.out.print("Introduce la nueva fecha de alta (YYYY-MM-DD): ");
        String fechaAlta = teclado.nextLine();

        String consulta = "UPDATE Empleado SET Nombre = ?, fechaAlta = ? WHERE codigoEmpleado = ?";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement sentencia = conexion.prepareStatement(consulta)) {

            sentencia.setString(1, nombre);
            sentencia.setString(2, fechaAlta);
            sentencia.setInt(3, codigoEmpleado);
            int filas = sentencia.executeUpdate();

            if (filas > 0) {
                System.out.println("Empleado modificado correctamente.");
            } else {
                System.out.println("Error al modificar el empleado.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void eliminarEmpleado() {

        System.out.print("Introduce el código del empleado a eliminar: ");
        int codigoEmpleado = teclado.nextInt();

        String consulta = "DELETE FROM Empleado WHERE codigoEmpleado = ?";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement sentencia = conexion.prepareStatement(consulta)) {

            sentencia.setInt(1, codigoEmpleado);
            int filas = sentencia.executeUpdate();

            if (filas > 0) {
                System.out.println("Empleado eliminado correctamente.");
            } else {
                System.out.println("Error al eliminar el empleado.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    
    //PRODUCTOS

    public static void gestionarProductos() {

        System.out.println("\nGestión de Productos:");
        System.out.println("1. Insertar producto");
        System.out.println("2. Modificar producto");
        System.out.println("3. Eliminar producto");
        System.out.print("Seleccione una opción: ");
        int opcion = teclado.nextInt();
        teclado.nextLine();  // Consumir el salto de línea

        switch (opcion) {
            case 1:
                insertarProducto();
                break;
            case 2:
                modificarProducto();
                break;
            case 3:
                eliminarProducto();
                break;
            default:
                System.out.println("Opción no válida.");
                break;
        }
    }

    private static void insertarProducto() {

        System.out.print("Introduce el nombre del producto: ");
        String nombre = teclado.nextLine();
        System.out.print("Introduce el precio del producto: ");
        float precio = teclado.nextFloat();
        System.out.print("Introduce el stock disponible: ");
        int stock = teclado.nextInt();

        String consulta = "INSERT INTO Producto (Nombre, PrecioUnitario, Stock) VALUES (?, ?, ?)";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement sentencia = conexion.prepareStatement(consulta)) {

            sentencia.setString(1, nombre);
            sentencia.setFloat(2, precio);
            sentencia.setInt(3, stock);
            int filas = sentencia.executeUpdate();

            if (filas > 0) {
                System.out.println("Producto insertado correctamente.");
            } else {
                System.out.println("Error al insertar el producto.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void modificarProducto() {
        System.out.print("Introduce el código del producto a modificar: ");
        int codigoProducto = teclado.nextInt();
        teclado.nextLine();  // Consumir el salto de línea

        System.out.print("Introduce el nuevo nombre del producto: ");
        String nombre = teclado.nextLine();
        System.out.print("Introduce el nuevo precio: ");
        float precio = teclado.nextFloat();
        System.out.print("Introduce el nuevo stock: ");
        int stock = teclado.nextInt();

        String consulta = "UPDATE Producto SET Nombre = ?, PrecioUnitario = ?, Stock = ? WHERE codigoProducto = ?";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement sentencia = conexion.prepareStatement(consulta)) {

            sentencia.setString(1, nombre);
            sentencia.setFloat(2, precio);
            sentencia.setInt(3, stock);
            sentencia.setInt(4, codigoProducto);
            int filas = sentencia.executeUpdate();

            if (filas > 0) {
                System.out.println("Producto modificado correctamente.");
            } else {
                System.out.println("Error al modificar el producto.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void eliminarProducto() {

        System.out.print("Introduce el código del producto a eliminar: ");
        int codigoProducto = teclado.nextInt();

        String consulta = "DELETE FROM Producto WHERE codigoProducto = ?";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement sentencia = conexion.prepareStatement(consulta)) {

            sentencia.setInt(1, codigoProducto);
            int filas = sentencia.executeUpdate();

            if (filas > 0) {
                System.out.println("Producto eliminado correctamente.");
            } else {
                System.out.println("Error al eliminar el producto.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void visualizarProductos() {
        // Consulta para obtener todos los productos
        String consulta = "SELECT * FROM Producto";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement sentencia = conexion.prepareStatement(consulta)) {

            ResultSet rs = sentencia.executeQuery();

            // Mostrar los productos
            System.out.println("\nProductos disponibles:");
            while (rs.next()) {
                int idProducto = rs.getInt("idProducto");
                String nombre = rs.getString("Nombre");
                float precio = rs.getFloat("PrecioUnitario");
                int stock = rs.getInt("Stock");
                System.out.println("ID: " + idProducto + " | Nombre: " + nombre + " | Precio: " + precio + " | Stock: " + stock);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    
    public static void realizarVenta() {

        System.out.println("\nRealizar Venta");

        // Solicitar el código de cliente
        System.out.print("Introduce el código del cliente: ");
        int codigoCliente = teclado.nextInt();
        teclado.nextLine();  // Consumir el salto de línea

        // Mostrar productos
        visualizarProductos();

        // Solicitar el código del producto y cantidad
        System.out.print("Introduce el código del producto que desea comprar: ");
        int codigoProducto = teclado.nextInt();
        System.out.print("Introduce la cantidad: ");
        int cantidad = teclado.nextInt();

        // Obtener datos del producto
        String consultaProducto = "SELECT * FROM producto WHERE idProducto = ?";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement stmtProducto = conexion.prepareStatement(consultaProducto)) {

            stmtProducto.setInt(1, codigoProducto);
            ResultSet rsProducto = stmtProducto.executeQuery();

            if (rsProducto.next()) {
                float precioUnitario = rsProducto.getFloat("PrecioUnitario");
                float total = precioUnitario * cantidad;

                // Insertar el ticket
                String insertarTicket = "INSERT INTO ticket (Cliente_numerodecliente, PrecioTotal) VALUES (?, ?)";
                try (PreparedStatement stmtTicket = conexion.prepareStatement(insertarTicket, PreparedStatement.RETURN_GENERATED_KEYS)) {
                    stmtTicket.setInt(1, codigoCliente);
                    stmtTicket.setFloat(2, total);
                    stmtTicket.executeUpdate();

                    // Obtener el ID del ticket recién insertado
                    ResultSet rsTicket = stmtTicket.getGeneratedKeys();
                    if (rsTicket.next()) {
                        int idTicket = rsTicket.getInt(1);

                        // Insertar la cantidad de productos en la tabla cantidadProducto
                        String insertarCantidadProducto = "INSERT INTO cantidadproducto (Ticket_idTicket, Producto_idProducto, Cantidad) VALUES (?, ?, ?)";
                        try (PreparedStatement stmtCantidad = conexion.prepareStatement(insertarCantidadProducto)) {
                            stmtCantidad.setInt(1, idTicket);
                            stmtCantidad.setInt(2, codigoProducto);
                            stmtCantidad.setInt(3, cantidad);
                            stmtCantidad.executeUpdate();

                            System.out.println("Venta realizada con éxito.");
                        }
                    }
                }
            } else {
                System.out.println("Producto no encontrado.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    

    public static void verTicketsGenerados() {

        System.out.print("Introduce tu código de empleado: ");
        int codigoEmpleado = teclado.nextInt();

        String consulta = "SELECT T.idTicket, T.PrecioTotal, T.Cliente_numeroCliente FROM Ticket T WHERE T.Empleado_codigoEmpleado = ?";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement stmt = conexion.prepareStatement(consulta)) {

            stmt.setInt(1, codigoEmpleado);
            ResultSet rs = stmt.executeQuery();

            System.out.println("\nTickets generados por el empleado:");
            while (rs.next()) {
                int idTicket = rs.getInt("idTicket");
                float precioTotal = rs.getFloat("PrecioTotal");
                int numeroCliente = rs.getInt("Cliente_numeroCliente");
                System.out.println("ID Ticket: " + idTicket + " | Precio Total: " + precioTotal + " | Cliente ID: " + numeroCliente);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void realizarCompra() {

        System.out.println("\nRealizar Compra");

        // Mostrar productos
        visualizarProductos();

        // Solicitar el código del producto y la cantidad
        System.out.print("Introduce el código del producto que desea comprar: ");
        int codigoProducto = teclado.nextInt();
        System.out.print("Introduce la cantidad: ");
        int cantidad = teclado.nextInt();

        // Consultar el precio y realizar el cálculo
        String consultaProducto = "SELECT * FROM Producto WHERE idProducto = ?";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement stmtProducto = conexion.prepareStatement(consultaProducto)) {

            stmtProducto.setInt(1, codigoProducto);
            ResultSet rsProducto = stmtProducto.executeQuery();

            if (rsProducto.next()) {
                float precioUnitario = rsProducto.getFloat("PrecioUnitario");
                float total = precioUnitario * cantidad;

                // Mostrar el total de la compra
                System.out.println("El total de la compra es: " + total);

                // Aquí se puede agregar la lógica de pago si se requiere.

                System.out.println("Compra realizada con éxito.");
            } else {
                System.out.println("Producto no encontrado.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void verHistorialCompras() {

        System.out.print("Introduce tu código de cliente: ");
        int codigoCliente = teclado.nextInt();

        String consulta = "SELECT * FROM Ticket WHERE Cliente_numeroCliente = ?";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement stmt = conexion.prepareStatement(consulta)) {

            stmt.setInt(1, codigoCliente);
            ResultSet rs = stmt.executeQuery();

            System.out.println("\nHistorial de compras del cliente:");
            while (rs.next()) {
                int idTicket = rs.getInt("idTicket");
                float precioTotal = rs.getFloat("PrecioTotal");
                System.out.println("ID Ticket: " + idTicket + " | Precio Total: " + precioTotal);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void canjearPuntos() {
        System.out.print("Introduce tu código de cliente: ");
        int codigoCliente = teclado.nextInt();

        // Obtener puntos del cliente
        String consultaPuntos = "SELECT puntos FROM Usuario WHERE Alias = (SELECT Usuario_Alias FROM Cliente WHERE numeroCliente = ?)";
        try (Connection conexion = ConexionBase.conectar(); 
             PreparedStatement stmtPuntos = conexion.prepareStatement(consultaPuntos)) {

            stmtPuntos.setInt(1, codigoCliente);
            ResultSet rsPuntos = stmtPuntos.executeQuery();

            if (rsPuntos.next()) {
                int puntosDisponibles = rsPuntos.getInt("puntos");

                System.out.println("Tienes " + puntosDisponibles + " puntos disponibles.");
                System.out.print("Introduce el número de puntos que deseas canjear: ");
                int puntosCanjear = teclado.nextInt();

                if (puntosCanjear <= puntosDisponibles) {
                    // Aplicar el descuento de puntos
                    float descuento = puntosCanjear; // 1 punto = 1 euro
                    System.out.println("Descuento aplicado: " + descuento + "€");

                    // Aquí puedes agregar la lógica para aplicar el descuento al ticket de compra.

                    System.out.println("Puntos canjeados con éxito.");
                } else {
                    System.out.println("No tienes suficientes puntos.");
                }

            } else {
                System.out.println("Cliente no encontrado.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
