package PracticaFinal;

import java.sql.*;

public class ConexionBase {
    private static final String URL = "jdbc:mysql://localhost:3307/practicafinal";
    private static final String USUARIO = "root";
    private static final String PASSWORD = "cfgs";
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

    public static Connection conectar() {
        try {
            Class.forName(DRIVER);
            return DriverManager.getConnection(URL, USUARIO, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error al conectar con la base de datos.");
            e.printStackTrace();
            return null;
        }
    }

    public static void ejecutarConsulta(String consulta) {
        try (Connection conexion = conectar()) {
            if (conexion == null) {
                throw new SQLException("No se pudo establecer la conexión.");
            }

            // Ejecutar la consulta
            try (PreparedStatement sentencia = conexion.prepareStatement(consulta);
                 ResultSet rs = sentencia.executeQuery()) {

                // Mostrar resultados
                while (rs.next()) {
                    int columnCount = rs.getMetaData().getColumnCount();
                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = rs.getMetaData().getColumnName(i);
                        String value = rs.getString(i);
                        System.out.print(columnName + ": " + value + " | ");
                    }
                    System.out.println();
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al ejecutar la consulta.");
            e.printStackTrace();
        }
    }
}
