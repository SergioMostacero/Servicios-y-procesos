package WindowBuilder.PanelAdmin;

import javax.swing.*;

import WindowBuilder.PanelPrincipal.PanelPrincipal;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConfiguracionApp extends JPanel {
    
    private JTextField txtMinutosFacil;
    private JTextField txtMinutosDificil;
    private JTextField txtErroresFacil;
    private JTextField txtErroresDificil;

    public ConfiguracionApp() {
        setLayout(new BorderLayout(10, 10));

        JLabel label = new JLabel("Configuración de la Aplicación", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 20));
        add(label, BorderLayout.NORTH);

        JPanel configuracionPanel = new JPanel();
        configuracionPanel.setLayout(new GridLayout(4, 2, 10, 10));

        // Configuración para minutos en el modo fácil
        JLabel lblMinutosFacil = new JLabel("Minutos (Modo Fácil): ");
        txtMinutosFacil = new JTextField("4");
        configuracionPanel.add(lblMinutosFacil);
        configuracionPanel.add(txtMinutosFacil);

        // Configuración para minutos en el modo difícil
        JLabel lblMinutosDificil = new JLabel("Minutos (Modo Difícil): ");
        txtMinutosDificil = new JTextField("3");
        configuracionPanel.add(lblMinutosDificil);
        configuracionPanel.add(txtMinutosDificil);

        // Configuración para errores en el modo fácil
        JLabel lblErroresFacil = new JLabel("Errores permitidos (Modo Fácil): ");
        txtErroresFacil = new JTextField("5");
        configuracionPanel.add(lblErroresFacil);
        configuracionPanel.add(txtErroresFacil);

        // Configuración para errores en el modo difícil
        JLabel lblErroresDificil = new JLabel("Errores permitidos (Modo Difícil): ");
        txtErroresDificil = new JTextField("3");
        configuracionPanel.add(lblErroresDificil);
        configuracionPanel.add(txtErroresDificil);

        add(configuracionPanel, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        JButton btnGuardar = new JButton("Guardar Configuración");
        btnGuardar.addActionListener(e -> guardarConfiguracion());
        btnPanel.add(btnGuardar);

        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> regresarAlPanelAdmin());
        btnPanel.add(btnVolver);

        add(btnPanel, BorderLayout.SOUTH);
    }

    private void guardarConfiguracion() {
        try {
            // Obtén los valores ingresados en los campos de texto
            int minutosFacil = Integer.parseInt(txtMinutosFacil.getText());
            int minutosDificil = Integer.parseInt(txtMinutosDificil.getText());
            int erroresFacil = Integer.parseInt(txtErroresFacil.getText());
            int erroresDificil = Integer.parseInt(txtErroresDificil.getText());

            // Validaciones para asegurar que los valores sean positivos
            if (minutosFacil <= 0 || minutosDificil <= 0 || erroresFacil < 0 || erroresDificil < 0) {
                JOptionPane.showMessageDialog(this, 
                    "Por favor, asegúrate de que los minutos sean mayores que cero y los errores no sean negativos.", 
                    "Error de Validación", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Actualiza la configuración en la clase PanelPrincipal
            PanelPrincipal.actualizarConfiguracion(minutosFacil, minutosDificil, erroresFacil, erroresDificil);

            // Muestra un mensaje de éxito
            JOptionPane.showMessageDialog(this, 
                String.format(
                    "Configuración guardada exitosamente:\n- Temporizador Fácil: %d minutos\n- Temporizador Difícil: %d minutos\n- Errores (Fácil): %d\n- Errores (Difícil): %d", 
                    minutosFacil, minutosDificil, erroresFacil, erroresDificil),
                "Configuración Guardada", JOptionPane.INFORMATION_MESSAGE);

            // Opcional: cerrar la ventana de configuración si se desea
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) {
                window.dispose(); // Cierra la ventana actual
            }

        } catch (NumberFormatException ex) {
            // Maneja el caso en que los valores ingresados no sean válidos
            JOptionPane.showMessageDialog(this, 
                "Por favor, ingresa valores numéricos válidos en todos los campos.", 
                "Error de Formato", JOptionPane.ERROR_MESSAGE);
        }
    }




    private void regresarAlPanelAdmin() {
        JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
        frame.getContentPane().removeAll();
        frame.getContentPane().add(new PanelAdmin());
        frame.revalidate();
        frame.repaint();
    }
}
