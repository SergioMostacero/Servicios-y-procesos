package WindowBuilder.PanelAdmin;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class CambiarLecciones extends JPanel {

    private JTextArea textAreaLeccion1;
    private JTextArea textAreaLeccion2;
    private JButton btnGuardarCambios;
    private JButton btnVolver;
    private static final String RUTA_FICHERO_TEXTOS = "src/GestorFichs/textos.txt";

    public CambiarLecciones() {
        setLayout(new BorderLayout(10, 10));

        // Crear componentes de texto
        textAreaLeccion1 = new JTextArea();
        textAreaLeccion2 = new JTextArea();

        textAreaLeccion1.setLineWrap(true);
        textAreaLeccion1.setWrapStyleWord(true);
        textAreaLeccion2.setLineWrap(true);
        textAreaLeccion2.setWrapStyleWord(true);

        JScrollPane scrollPane1 = new JScrollPane(textAreaLeccion1);
        JScrollPane scrollPane2 = new JScrollPane(textAreaLeccion2);

        JPanel panelEdicion = new JPanel();
        panelEdicion.setLayout(new GridLayout(2, 1, 5, 5));
        panelEdicion.add(scrollPane1);
        panelEdicion.add(scrollPane2);

        add(panelEdicion, BorderLayout.CENTER);

        // Crear botones
        btnGuardarCambios = new JButton("Guardar Cambios");
        btnVolver = new JButton("Volver a PanelAdmin");

        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new FlowLayout());
        panelBotones.add(btnGuardarCambios);
        panelBotones.add(btnVolver);

        add(panelBotones, BorderLayout.SOUTH);

        // Cargar lecciones automáticamente
        cargarLecciones();

        // Configurar acciones de los botones
        configurarAcciones();
    }

    private void configurarAcciones() {
        btnGuardarCambios.addActionListener(e -> guardarCambios());
        btnVolver.addActionListener(e -> volverPanelAdmin());
    }

    private void cargarLecciones() {
        try (BufferedReader br = new BufferedReader(new FileReader(RUTA_FICHERO_TEXTOS))) {
            String linea = br.readLine();
            if (linea != null) {
                String[] textos = linea.split(";");
                if (textos.length == 2) {
                    textAreaLeccion1.setText(textos[0]);
                    textAreaLeccion2.setText(textos[1]);
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo cargar el contenido inicial: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardarCambios() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_FICHERO_TEXTOS, false))) {
            String texto1 = textAreaLeccion1.getText();
            String texto2 = textAreaLeccion2.getText();
            bw.write(texto1 + ";" + texto2);
            JOptionPane.showMessageDialog(this, "Cambios guardados correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar los cambios: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void volverPanelAdmin() {
        JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
        frame.getContentPane().removeAll();
        frame.getContentPane().add(new PanelAdmin());
        frame.revalidate();
        frame.repaint();
    }
}
