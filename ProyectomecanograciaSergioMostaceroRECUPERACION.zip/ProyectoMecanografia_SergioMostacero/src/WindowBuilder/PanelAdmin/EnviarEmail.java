package WindowBuilder.PanelAdmin;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.*;
import java.awt.*;
import java.util.Properties;

public class EnviarEmail extends JPanel {

    private JTextField emailField;
    private JTextField asuntoField;
    private JTextArea textoCorreo;
    private JButton btnEnviar;
    private JButton btnVolver;

    public EnviarEmail() {
        // Configurar el diseño principal
        setLayout(new BorderLayout(10, 10));

        // Panel para ingresar información de correo
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2, 5, 5));

        // Campos de entrada
        JLabel lblCorreo = new JLabel("Correo Destinatario:");
        emailField = new JTextField();
        JLabel lblAsunto = new JLabel("Asunto:");
        asuntoField = new JTextField();
        JLabel lblTexto = new JLabel("Texto del Correo:");
        textoCorreo = new JTextArea(5, 20);
        textoCorreo.setLineWrap(true);
        textoCorreo.setWrapStyleWord(true);

        JScrollPane scrollTexto = new JScrollPane(textoCorreo);

        // Añadir campos al panel
        inputPanel.add(lblCorreo);
        inputPanel.add(emailField);
        inputPanel.add(lblAsunto);
        inputPanel.add(asuntoField);
        inputPanel.add(lblTexto);
        inputPanel.add(scrollTexto);

        // Crear los botones
        btnEnviar = new JButton("Enviar Correo");
        btnVolver = new JButton("Volver a Panel Admin");

        // Crear panel para los botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        buttonPanel.add(btnEnviar);
        buttonPanel.add(btnVolver);

        // Agregar componentes al panel principal
        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Configurar acciones de los botones
        btnEnviar.addActionListener(e -> enviarCorreo());
        btnVolver.addActionListener(e -> regresarAlPanelAdmin());
    }

    private void enviarCorreo() {
        String destinatario = emailField.getText();
        String asunto = asuntoField.getText();
        String mensajeTexto = textoCorreo.getText();

        if (destinatario.isEmpty() || asunto.isEmpty() || mensajeTexto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor complete todos los campos.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            enviarCorreoSMTP(destinatario, asunto, mensajeTexto);
            JOptionPane.showMessageDialog(this, "Correo enviado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al enviar el correo: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void enviarCorreoSMTP(String destinatario, String asunto, String mensajeTexto) throws MessagingException {
        String username = "smosta0@gmail.com";
        String password = "ausd fage nhzi xuec";

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "465");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.socketFactory.port", "465");
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

        Session session = Session.getInstance(prop, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(username));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
        message.setSubject(asunto);
        message.setText(mensajeTexto);

        Transport.send(message);
    }

    private void regresarAlPanelAdmin() {
        JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
        frame.getContentPane().removeAll();
        frame.getContentPane().add(new PanelAdmin());
        frame.revalidate();
        frame.repaint();
    }
}
