package WindowBuilder.PanelAdmin;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

import WindowBuilder.Loading.FramePrincipal;

import java.awt.Font;
import java.util.Properties;
import java.awt.Cursor;
import javax.swing.JOptionPane;

public class PanelAdmin extends JPanel {
	

    private static final long serialVersionUID = 1L;

    private JLabel titulo;
    private JButton gestionarAltasBajas;
    private JButton configuracionApp;
    private JButton probarEmail;
    private JButton cambiarArchivoLecciones;
    JButton btnVolver;

    public PanelAdmin() {
        setLayout(null);

        titulo = new JLabel("PANEL DE ADMINISTRADOR");
        titulo.setFont(new Font("UniSansSemiBold", Font.PLAIN, 18));
        titulo.setBounds(80, 20, 300, 30);
        add(titulo);

        gestionarAltasBajas = new JButton("Gestionar Altas/Bajas");
        gestionarAltasBajas.setBounds(100, 80, 200, 50);
        gestionarAltasBajas.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        gestionarAltasBajas.addActionListener(e -> JOptionPane.showMessageDialog(this, "Funcionalidad de Altas/Bajas en desarrollo."));
        add(gestionarAltasBajas);

        configuracionApp = new JButton("Configuración de la App");
        configuracionApp.setBounds(100, 150, 200, 50);
        configuracionApp.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        configuracionApp.addActionListener(e -> JOptionPane.showMessageDialog(this, "Configuración de la app en desarrollo."));
        add(configuracionApp);

        probarEmail = new JButton("Probar Envío de Emails");
        probarEmail.setBounds(100, 220, 200, 50);
        probarEmail.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        probarEmail.addActionListener(e -> {
            String destinatario = "correo.prueba@gmail.com"; // Cambia esto por un correo de prueba válido

            // Configuración SMTP
            String username = "smosta0@gmail.com";
            String password = "ausd fage nhzi xuec";

            Properties prop = new Properties();
            prop.put("mail.smtp.host", "smtp.gmail.com");
            prop.put("mail.smtp.port", "465");
            prop.put("mail.smtp.auth", "true");
            prop.put("mail.smtp.socketFactory.port", "465");
            prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

            Session session = Session.getInstance(prop, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            });

            try {
                // Prueba de conexión al servidor SMTP
                Transport transport = session.getTransport("smtp");
                transport.connect("smtp.gmail.com", username, password);
                transport.close();

                // Enviar correo de prueba
                MimeMessage message = new MimeMessage(session);
                message.setFrom(new InternetAddress(username));
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
                message.setSubject("Prueba de conexión SMTP");
                message.setText("Este es un correo de prueba para verificar la conexión SMTP.");

                Transport.send(message);
                JOptionPane.showMessageDialog(this, "Correo de prueba enviado exitosamente a " + destinatario);

            } catch (MessagingException ex) {
                JOptionPane.showMessageDialog(this, "Error al enviar correo: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        add(probarEmail);


        cambiarArchivoLecciones = new JButton("Cambiar Archivo de Lecciones");
        cambiarArchivoLecciones.setBounds(100, 290, 200, 50);
        cambiarArchivoLecciones.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        cambiarArchivoLecciones.addActionListener(e -> JOptionPane.showMessageDialog(this, "Cambio de archivo de lecciones en desarrollo."));
        add(cambiarArchivoLecciones);
        
        
        
        
        btnVolver = new JButton("Volver");
		btnVolver.setBounds(0, 0, 89, 23);
		btnVolver.setFocusable(false);
		add(btnVolver);
        
      
    }

	public JButton getBtnVolver() {
		return btnVolver;
	}
    
}

