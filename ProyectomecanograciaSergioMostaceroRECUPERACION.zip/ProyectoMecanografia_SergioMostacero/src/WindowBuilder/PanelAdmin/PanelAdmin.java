package WindowBuilder.PanelAdmin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import WindowBuilder.*;
import WindowBuilder.Loading.FramePrincipal;

public class PanelAdmin extends JPanel {
    // Botones
    private JButton btnGestionUsuarios;
    private JButton BtnVolver;
    private JButton btnCambiarLecciones;
    private JButton btnEnviarEmail;
    private JButton btnConfiguracionApp; // Nuevo botón
    private Image backgroundImage;

    public PanelAdmin() {
        // Cargar la imagen de fondo
        backgroundImage = new ImageIcon("src/imagenes/FONDOADMIN.jpg").getImage();

        // Configurar layout
        setLayout(null);

        // Inicialización de los botones
        BtnVolver = new JButton("Volver al Login");
        BtnVolver.setBounds(119, 369, 178, 63);
        btnGestionUsuarios = new JButton("Gestionar Usuarios");
        btnGestionUsuarios.setBounds(119, 147, 178, 63);
        btnCambiarLecciones = new JButton("Cambiar Lecciones");
        btnCambiarLecciones.setBounds(119, 221, 178, 63);
        btnEnviarEmail = new JButton("Enviar Email");
        btnEnviarEmail.setBounds(115, 70, 182, 66);

        // Botón de configuración de la app
        btnConfiguracionApp = new JButton("Configuración de la App");
        btnConfiguracionApp.setBounds(119, 295, 178, 63);

        // Agregar los botones al panel
        add(btnGestionUsuarios);
        add(btnCambiarLecciones);
        add(btnEnviarEmail);
        add(BtnVolver);
        add(btnConfiguracionApp);

        JLabel PanelAdmin = new JLabel("ADMINISTRADOR");
        PanelAdmin.setFont(new Font("Times New Roman", Font.BOLD, 30));
        PanelAdmin.setBounds(69, 11, 272, 48);
        add(PanelAdmin);

        // Configurar las acciones de los botones
        configurarAcciones();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Dibujar la imagen de fondo ajustada al tamaño del panel
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }

    // Método para configurar las acciones de cada botón
    private void configurarAcciones() {
        // Acción para el botón "Gestionar Usuarios"
        btnGestionUsuarios.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GestionUsuarios gestionUsuarios = new GestionUsuarios();
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(PanelAdmin.this);
                frame.getContentPane().removeAll();
                frame.getContentPane().add(gestionUsuarios);
                frame.revalidate();
                frame.repaint();
            }
        });

        // Acción para el botón "Cambiar Lecciones"
        btnCambiarLecciones.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CambiarLecciones cambiarLecciones = new CambiarLecciones();
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(PanelAdmin.this);
                frame.getContentPane().removeAll();
                frame.getContentPane().add(cambiarLecciones);
                frame.revalidate();
                frame.repaint();
            }
        });

        // Acción para el botón "Enviar Email"
        btnEnviarEmail.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(PanelAdmin.this);
                frame.getContentPane().removeAll();
                frame.getContentPane().add(new EnviarEmail());
                frame.revalidate();
                frame.repaint();
            }
        });

        // Acción para el botón "Volver al Login"
        BtnVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(PanelAdmin.this);
                if (frame instanceof FramePrincipal) {
                    ((FramePrincipal) frame).eventoLogIn();
                }
            }
        });

        // Acción para el nuevo botón de configuración
        btnConfiguracionApp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(PanelAdmin.this);
                frame.getContentPane().removeAll();
                frame.getContentPane().add(new ConfiguracionApp());
                frame.revalidate();
                frame.repaint();
            }
        });
    }
 // Métodos para acceder a los botones desde fuera de la clase, si es necesario
    public JButton getBtnGestionUsuarios() {
        return btnGestionUsuarios;
    }

    public JButton getBtnVolver() {
        return BtnVolver;
    }

    public JButton getBtnCambiarLecciones() {
        return btnCambiarLecciones;
    }

    public JButton getBtnEnviarEmail() {
        return btnEnviarEmail;
    }
}
