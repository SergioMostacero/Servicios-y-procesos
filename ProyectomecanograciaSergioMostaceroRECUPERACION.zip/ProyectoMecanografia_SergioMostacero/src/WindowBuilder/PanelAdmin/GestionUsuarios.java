package WindowBuilder.PanelAdmin;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class GestionUsuarios extends JPanel {

    private JTable tableUsuarios;
    private DefaultTableModel tableModel;
    private JButton btnGuardar;
    private JButton btnVolver;
    private JButton btnAñadirUsuario;
    private JButton btnEliminarUsuario;

    private static final String RUTA_FICHERO_USUARIOS = "src/GestorFichs/usuarios.txt";

    public GestionUsuarios() {
        // Configurar layout principal
        setLayout(new BorderLayout(10, 10));

        // Crear modelo de tabla
        tableModel = new DefaultTableModel(new String[]{"ID", "Usuario", "Contraseña", "Email"}, 0);
        tableUsuarios = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(tableUsuarios);

        // Botones
        btnAñadirUsuario = new JButton("Añadir Usuario");
        btnEliminarUsuario = new JButton("Eliminar Usuario");
        btnGuardar = new JButton("Guardar Cambios");
        btnVolver = new JButton("Volver a PanelAdmin");

        // Crear panel para botones
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(2, 2, 10, 10)); // 2 filas, 2 columnas con espacio entre botones
        panelBotones.add(btnAñadirUsuario);
        panelBotones.add(btnEliminarUsuario);
        panelBotones.add(btnGuardar);
        panelBotones.add(btnVolver);

        // Agregar componentes al panel principal
        add(scrollPane, BorderLayout.CENTER); // Tabla en el centro
        add(panelBotones, BorderLayout.SOUTH); // Botones en la parte inferior

        // Cargar usuarios automáticamente al inicializar
        cargarUsuarios();

        // Configurar acciones de los botones
        configurarAcciones();
    }

    private void configurarAcciones() {
        // Acción para añadir un usuario
        btnAñadirUsuario.addActionListener(e -> {
            // Agregar una fila vacía para editar
            tableModel.addRow(new Object[]{"", "", "", ""});
        });

        // Acción para eliminar un usuario
        btnEliminarUsuario.addActionListener(e -> {
            int filaSeleccionada = tableUsuarios.getSelectedRow();
            if (filaSeleccionada >= 0) {
                tableModel.removeRow(filaSeleccionada);
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un usuario para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        });

        // Acción para guardar cambios
        btnGuardar.addActionListener(e -> guardarUsuarios());

        // Acción para volver al PanelAdmin
        btnVolver.addActionListener(e -> regresarAlPanelAdmin());
    }

    private void cargarUsuarios() {
        try (BufferedReader br = new BufferedReader(new FileReader(RUTA_FICHERO_USUARIOS))) {
            String linea;

            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(";");
                if (datos.length == 4) {
                    tableModel.addRow(datos);
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar los usuarios: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //UNA VEZ INTRODUCE SEL ULTIMO PARAMETRO NO PUEDE ESTAR SELECCIONADO PORQUE LO DETECTA COMO PARAMETRO VACIO Y NO SE GUARDA
    private void guardarUsuarios() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_FICHERO_USUARIOS, false))) {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String id = tableModel.getValueAt(i, 0) == null ? "" : tableModel.getValueAt(i, 0).toString();
                String usuario = tableModel.getValueAt(i, 1) == null ? "" : tableModel.getValueAt(i, 1).toString();
                String contrasena = tableModel.getValueAt(i, 2) == null ? "" : tableModel.getValueAt(i, 2).toString();
                String email = tableModel.getValueAt(i, 3) == null ? "" : tableModel.getValueAt(i, 3).toString();
                
                // Imprime los valores para asegurarte de que no están vacíos
                System.out.println("Guardando: " + id + ", " + usuario + ", " + contrasena + ", " + email);
                
                bw.write(id + ";" + usuario + ";" + contrasena + ";" + email);
                bw.newLine();
            }

            JOptionPane.showMessageDialog(this, "Cambios guardados correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar los cambios: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void regresarAlPanelAdmin() {
        JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(GestionUsuarios.this);
        frame.getContentPane().removeAll();
        frame.getContentPane().add(new PanelAdmin());
        frame.revalidate();
        frame.repaint();
    }
}
