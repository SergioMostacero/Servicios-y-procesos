package WindowBuilder.Login;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.border.MatteBorder;

import Password.PasswordEvent;

import java.awt.Cursor;

public class PanelLogin extends JPanel {

    private JLabel titulo;
    private JLabel usuario;
    private JLabel contrasena;

    private JTextField usuarioField;
    private JPasswordField contrasenaField;

    private JButton botonInicio;
    private JCheckBox mostrarPsw;

    private Image fondoImagen;

    public PanelLogin() {
        // Cargar la imagen de fondo
        fondoImagen = new ImageIcon("src/imagenes/fondoInicioSesion.jpg").getImage();

        setLayout(null);
        setName("Inicio de sesion");

        titulo = new JLabel("INICIO SESIÓN");
        titulo.setFont(new Font("Eras Demi ITC", Font.PLAIN, 32));
        titulo.setBounds(104, 11, 229, 77);

        usuario = new JLabel("Usuario :");
        usuario.setFont(new Font("Dialog", Font.PLAIN, 20));
        usuario.setBounds(89, 120, 78, 35);

        //seccione spra introducir el usuario con su textField
        usuarioField = new JTextField();
        usuarioField.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
        usuarioField.setFont(new Font("UniSansRegular", Font.PLAIN, 13));
        usuarioField.setBounds(206, 131, 106, 20);
        usuarioField.setVisible(true);
        usuarioField.setColumns(10);

       //seccion para poner la contraseña con su passwordField
        contrasena = new JLabel("Contraseña :");
        contrasena.setFont(new Font("Dialog", Font.PLAIN, 20));
        contrasena.setBounds(54, 202, 113, 29);

        contrasenaField = new JPasswordField();
        contrasenaField.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 0)));
        contrasenaField.setBounds(206, 210, 106, 20);
        contrasenaField.setFont(new Font("UniSansRegular", Font.PLAIN, 13));

        contrasenaField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (usuarioField.getText().length() >= 10) {
                    e.consume();
                }
            }
        });

        usuarioField.addKeyListener(new KeyAdapter() {

        });

        // Mostrar/ocultar la contraseña
        mostrarPsw = new JCheckBox();
        mostrarPsw.setVisible(true);
        mostrarPsw.setBounds(329, 211, 21, 20);

        PasswordEvent passwordEvent = new PasswordEvent(mostrarPsw, contrasenaField);
        mostrarPsw.addActionListener(passwordEvent);

        botonInicio = new JButton("INICIAR SESIÓN");
        botonInicio.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        botonInicio.setVisible(true);
        botonInicio.setBounds(119, 353, 170, 50);

        // Añadir todos los componentes al panel
        add(usuario);
        add(contrasena);
        add(titulo);
        add(botonInicio);
        add(usuarioField);
        add(contrasenaField);
        add(mostrarPsw);
        
        setVisible(true);
    }

    // Sobrescribir el método paintComponent para dibujar la imagen de fondo
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Dibujar la imagen de fondo ajustada al tamaño del panel
        g.drawImage(fondoImagen, 0, 0, getWidth(), getHeight(), this);
    }

    public JButton getBotonInicio() {
        return botonInicio;
    }

    public void setBotonInicio(JButton botonInicio) {
        this.botonInicio = botonInicio;
    }

    public JTextField getUsuarioField() {
        return usuarioField;
    }

    public void setUsuarioField(JTextField usuarioField) {
        this.usuarioField = usuarioField;
    }

    public JPasswordField getContrasenaField() {
        return contrasenaField;
    }

    public void setContrasenaField(JPasswordField contrasenaField) {
        this.contrasenaField = contrasenaField;
    }
}
