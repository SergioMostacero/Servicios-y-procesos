package GestorFichs;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class DatosFicheros {

	private ArrayList<Usuario> listaUsuarios; //almacenar datos leidos de los usuarios
	private ArrayList<String> textos; //almacenar los textos
	private ArrayList<Estadisticas> estadisticas; // almacenar las stats

	private SimpleDateFormat formato;
	private Date fechaDate;

	public DatosFicheros(ArrayList<Usuario> listaUsuarios, ArrayList<String> textos, ArrayList<Estadisticas> estadisticas) {
		this.estadisticas = estadisticas;
		this.listaUsuarios = listaUsuarios;
		this.textos = textos;
	}

	public DatosFicheros(ArrayList<String> textos, ArrayList<Estadisticas> estadisticas) {
		this.textos = textos;
		this.estadisticas = estadisticas;
	}

	
	//verificar si los archivos existen
	public void comprobarFile() {

		File usuarioFile = new File("src/GestorFichs/usuarios.txt");
		File estadisticasFile = new File("src/GestorFichs/estadisticas.txt");
		File textosFiles = new File("src/GestorFichs/textos.txt");

		if(!(usuarioFile.exists() && estadisticasFile.exists() && textosFiles.exists())) {

			JOptionPane.showMessageDialog(null, "Error no se han detectado los archivos ", "ERROR", 0);
			System.exit(0);

		}
	}

	
	//leer archivos usuarios se separan los usuarios por ;
	public void accederFicheroUsuario(String fichero) {
		try {

			FileReader fr = new FileReader(fichero);
			BufferedReader br = new BufferedReader(fr);
			String leerDatos;

			leerDatos = br.readLine();
			//guardamos los datos introducidos de usuario,nombre, contraseña, email 
			while(leerDatos != null) {
				listaUsuarios.add(new Usuario((leerDatos.split(";")[0]), (leerDatos.split(";")[1]), (leerDatos.split(";")[2]), (leerDatos.split(";")[3])));
				leerDatos = br.readLine();
			}

			br.close();

		}catch(IOException e) {
			JOptionPane.showMessageDialog(null, "Error al leer los usuarios", "ERROR", 0);			
			System.exit(0);
		}
	}


	//lee las estadisticas se separan por ; tambien
	public void accederDatosEstadisticas(String fichero) {
		try {

			formato = new SimpleDateFormat("dd-MM-yyyy-HH::mm:ss");
			fechaDate = null;

			FileReader fr = new FileReader(fichero);
			BufferedReader br = new BufferedReader(fr);
			String leerStats;

			leerStats = br.readLine();

			while(leerStats != null) {
				
					fechaDate = formato.parse(leerStats.split(";")[6]);
				
				this.estadisticas.add(new Estadisticas(leerStats.split(";")[0],
						Boolean.valueOf(leerStats.split(";")[1]),
						Integer.parseInt(leerStats.split(";")[2]),
						Integer.parseInt(leerStats.split(";")[3]),
						Integer.parseInt(leerStats.split(";")[4]),
						Integer.parseInt(leerStats.split(";")[5]),
						fechaDate
						));
				leerStats = br.readLine();
			}

			br.close();

		}catch(IOException e) {
			JOptionPane.showMessageDialog(null, "Error en la lecutra de fechas", "Error", 0);
			System.exit(0);
		} catch (ParseException e) {
			JOptionPane.showMessageDialog(null, "Error de formato fecha, cerrando el programa...", "Error de formato", JOptionPane.CANCEL_OPTION);
			System.exit(9);
		}
	}

	
	//al terminar el juego sobrescribe losa datos
	public void sobreescribirDatosStats(ArrayList<Usuario> listaUsuarios, String ruta) {

	    try {
	        File f = new File(ruta);
	        FileWriter fw = new FileWriter(f, false);
	        BufferedWriter bw = new BufferedWriter(fw);
	        SimpleDateFormat formato = new SimpleDateFormat("dd-MM-yyyy-HH::mm:ss");

	        for (Usuario usuario : listaUsuarios) {
	            if (usuario.getEstadiscitas() != null) {
	                for (Estadisticas estadistica : usuario.getEstadiscitas()) {
	                    bw.write(estadistica.getIdUsuario());
	                    bw.write(";");
	                    bw.write(String.valueOf(estadistica.isDificultad()));
	                    bw.write(";");
	                    bw.write(String.valueOf(estadistica.getPpm()));
	                    bw.write(";");
	                    bw.write(String.valueOf(estadistica.getError()));
	                    bw.write(";");
	                    bw.write(String.valueOf(estadistica.getTiempoMinutos()));
	                    bw.write(";");
	                    bw.write(String.valueOf(estadistica.getTiempoSegundos()));
	                    bw.write(";");
	                    bw.write(formato.format(estadistica.getDate()));
	                    bw.newLine();
	                }
	            }
	        }

	        bw.close();
	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(null, "Error al escribir en el archivo: " + e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
	    }
	}



	//Metodo que sirve para leer los datos de los textos y poder separarlos, el add(0) equivale al facil y el add(1) al dificil
	public void leerDatosTexto(String ruta) {
		try {
			FileReader fr = new FileReader(ruta);
			BufferedReader br = new BufferedReader(fr);
			String lineaTexto;

			lineaTexto = br.readLine();
			while(lineaTexto != null ) {

				textos.add(lineaTexto.split(";")[0]);
				textos.add(lineaTexto.split(";")[1]);
				lineaTexto = br.readLine();
			}
			br.close();
		}catch(IOException e) {
			JOptionPane.showMessageDialog(null, "Error al leer los datos", "ERROR", 0);
			System.exit(0);
		}
	}

}
